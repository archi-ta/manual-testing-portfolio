# Test Summary Report

## Project
Manual testing of a login page

## Test environment
- Application / URL: [Fill after choosing a practice application]
- Operating system: [Fill in]
- Browser and version: [Fill in]
- Test date: [Fill in]

## Scope
Login form behavior, including valid input, invalid input, empty fields, and basic field behavior.

## Execution results
Fill this section only after running the test cases.

| Metric | Count |
|---|---:|
| Total test cases | 10 |
| Passed | Not run |
| Failed | Not run |
| Blocked | Not run |
| Not run | 10 |

## Defects
- Defects observed: [Fill in after execution]
- Bug report links / IDs: [Add links or IDs, if any]

## Conclusion
Testing has not been executed yet. Update this report after manually running the test cases. Do not claim a pass rate or defect count before execution.
