# Bug Report Template

> Copy this template for each defect you personally observe. Do not report hypothetical issues as real bugs.

- **Bug ID:** BUG-001
- **Title:** [Short, clear description]
- **Application / page:** [Name and page]
- **Environment:** [Browser, operating system, device]
- **Build / URL:** [Version or URL, if appropriate]
- **Severity:** [Critical / High / Medium / Low]
- **Priority:** [High / Medium / Low]
- **Preconditions:** [What must be true before testing]
- **Steps to reproduce:**
  1. [Step 1]
  2. [Step 2]
  3. [Step 3]
- **Expected result:** [What should happen]
- **Actual result:** [What actually happened]
- **Reproducibility:** [e.g., 3 out of 3 attempts]
- **Evidence:** [Screenshot or recording, with private information removed]
- **Status:** [New / Open / In Progress / Fixed / Retest / Closed]

## Example title format
`[Login] Error message is not displayed after invalid password`

Only use this title if you actually observe that behavior in the application being tested.
