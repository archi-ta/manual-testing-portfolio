# Manual Testing Portfolio — Login Page

## Project overview
This beginner project demonstrates how to document manual test cases for a typical login page.

**Important:** This is a practice portfolio/template. The test cases have not been executed against a real application. Do not claim bugs were found or that testing passed until you run the tests and record the results.

## Objective
Practice writing positive and negative test cases, recording expected and actual results, and reporting defects clearly.

## Scope and assumptions
This example assumes a login page has a username field, password field, login button, a success destination after valid credentials, and an error message after invalid credentials. These are example assumptions, not verified requirements for a specific product.

## Files
- `Test-Cases.xlsx` — test cases with steps, expected results, and execution fields
- `Bug-Report-Template.md` — reusable defect-report template
- `Test-Summary.md` — template for recording actual testing outcomes

## How to use
1. Choose a demo application or practice login page you are allowed to test.
2. Confirm its actual requirements and update assumptions.
3. Execute each test case manually.
4. Fill in **Actual Result** and **Status** in the spreadsheet.
5. If you observe a real defect, create a report using the bug template.
6. Update `Test-Summary.md` with actual results.

## Key terms
- **Test case:** Steps and data used to check one behavior.
- **Expected result:** What should happen according to the requirement.
- **Actual result:** What happened when you performed the test.
- **Defect/bug:** A difference between expected and actual behavior.
- **Positive testing:** Checking valid inputs and normal use.
- **Negative testing:** Checking invalid, missing, or unexpected inputs.

## Current status
Practice documentation created. Test execution is **Not Run** until you personally execute the cases.
